package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entities.Product;
import com.cg.service.IProductService;

@Controller
public class ProductController 
{
	@Autowired
	IProductService productService;

	public ProductController() {
		super();
		
	}

	public ProductController(IProductService productService) {
		super();
		this.productService = productService;
	}

	public IProductService getProductService() {
		return productService;
	}

	public void setProductService(IProductService productService) {
		this.productService = productService;
	}
	
	
	@RequestMapping("home")
	public String getHomePage()
	{
		return "HomePage";
	}
	
	
	//intializing addProduct jsp
	
	@RequestMapping("addproduct")
	public String getAddProductPage(Model model)
	{
		
		//init the date for category drop dwon list
		List<String> categories = new ArrayList();
		categories.add("shoes");
		categories.add("Mobiles");
		categories.add("Clothes");
		categories.add("HomeTools");
		categories.add("Furniture");
		categories.add("Vegetables");
		
		
		//Add the form backing bean to be binded to AddProduct.jsp Form
		model.addAttribute("product", new Product());
		
		//Add categories to build the drop down list in AddProduct dynamically
		model.addAttribute("categories",categories);
		
		//Return view name
		return "AddProductPage";
	}
	
	
	@RequestMapping(value="processAddProductForm")
	public ModelAndView processAddProductForm
		(@ModelAttribute("product") @Valid Product product,
		BindingResult result, Model model)
	{
		if (result.hasErrors() == true)
		{
			//init the date for category drop dwon list
			List<String> categories = new ArrayList();
			categories.add("shoes");
			categories.add("Mobiles");
			categories.add("Clothes");
			categories.add("HomeTools");
			categories.add("Furniture");
			categories.add("Vegetables");
			
			
			//Add the form backing bean to be binded to AddProduct.jsp Form
			model.addAttribute("product", product);
			
			//Add categories to build the drop down list in AddProduct dynamically
			model.addAttribute("categories",categories);
			
			
			return new ModelAndView("AddProductPage");
		}
		
		 int productId = -1;
		 try
			{
				 productId = productService.addProduct(product);
				 model.addAttribute("message", "Product Added Successfully. Product id:"+ productId);
				 return new ModelAndView("SuccessPage");
			} 
		 
		catch (Exception e)
		 
			{
				model.addAttribute("errorMsg", "Could not add product. Reason"+ e.getMessage());
				return new ModelAndView("ErrorPage");
			}
		
	}
	
	@RequestMapping("getproduct")
	public String getProductPage()
	{
		return "GetProductPage";
	}

	@RequestMapping("processgetproductform")
	public ModelAndView processGetProductForm(@RequestParam("productId") int pid)
	{
		Product product = null;
		try 
			{
			product = productService.getProduct(pid);
		
			return new ModelAndView("GetProductPage", "product", product);
			
			} 
		catch (Exception e) 
			{
			 return new ModelAndView("ErrorPage", "errorMsg",
					 "Could not retrive the product.Reason:" +e.getMessage());
			}
	}
	
	@RequestMapping("viewallproducts")
	public String getViewAllProductsPage(Model model)
	{
		List<Product> products = null;
		try 
			{
				products = productService.getAllProducts();		
				model.addAttribute("products", products);
			} 
		catch (Exception e)
			{
			 
				model.addAttribute("errorMsg",
					 "Could not display the product.Reason:" +e.getMessage());
				
				return "ErrorPage";
			}
		
		
		return "ViewAllProductsPage";
	}
	
	@RequestMapping("getupdatepage")
	
	public String getUpdatePage(@RequestParam("pid") int id, Model model)
	{
		
		//init the date for category drop dwon list
				List<String> categories = new ArrayList();
				categories.add("shoes");
				categories.add("Mobiles");
				categories.add("Clothes");
				categories.add("HomeTools");
				categories.add("Furniture");
				categories.add("Vegetables");
				
				Product product = null;
				
				try
				{
					product = productService.getProduct(id);
					
				}
				catch(Exception e)
				{
					model.addAttribute("errorMsg","Could not retrive ProductDetails.Reason" +e.getMessage());
					return "ErrorPage";
				}
		
				
				//Add the form backing bean to be binded to AddProduct.jsp Form
				model.addAttribute("product",  product);
				
				//Add categories to build the drop down list in AddProduct dynamically
				model.addAttribute("categories",categories);
	
				
		return "UpdatePage";
	}
	
	@RequestMapping(value="processupdatepageform", method=RequestMethod.POST)
	public String processUpdatePageForm(
			@ModelAttribute("product") @Valid Product product,
			BindingResult result, Model model)
			{
				if(result.hasErrors() == true)
				{
					//init the date for category drop dwon list
					List<String> categories = new ArrayList();
					categories.add("shoes");
					categories.add("Mobiles");
					categories.add("Clothes");
					categories.add("HomeTools");
					categories.add("Furniture");
					categories.add("Vegetables");
					
					
					//Add the form backing bean to be binded to AddProduct.jsp Form
					model.addAttribute("product", product);
					
					//Add categories to build the drop down list in AddProduct dynamically
					model.addAttribute("categories",categories);
					
					return "UpdatePage";
				}
				
				try 
				{
					productService.updateProduct(product);
				} 
				catch (Exception e) 
				{
					model.addAttribute("errorMsg", "Could Not Update Product Details. Reason:" +e.getMessage());
					return "ErrorPage";
				}
				
				
					model.addAttribute("message", "Product Updated Successfully");
					return "SuccessPage";
			}
	
		}
	
	



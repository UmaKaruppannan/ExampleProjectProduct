package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Entity
@Table(name="ProductDetails")	//if table name are not matching
@NamedQueries(
@NamedQuery(name="getAllProduct",query="Select p from Product p"))
@Component("product")
public class Product 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseqgen")		//to auto generate id.
	@SequenceGenerator(name="myseqgen" ,sequenceName="productid_seq",initialValue=1000)
	@Column(name="id")
	private int id;
	
		
	@NotEmpty(message="Name cannotbe empty")
	@Column(name="name" , nullable=false)		//this is used when column name are different
	private String name;
	
	
	
	@Min(value=1, message="Quantity cannot be less then zero")
	@Column(name="quantity",nullable=false)
	private int quantity;
	
	
	
	@NotEmpty(message="category cannot be empty")
	@Column(name="category",nullable=false)
	private String category;
	
	
	
	@Min(value=10, message="Product price must be greater then or equal to 10 Rs")
	@Column(name="price",nullable=false)
	private float price;



	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Product(String name, int quantity, String category, float price) {
		super();
		this.name = name;
		this.quantity = quantity;
		this.category = category;
		this.price = price;
	}



	public Product(int id, String name, int quantity, String category,
			float price) {
		super();
		this.id = id;
		this.name = name;
		this.quantity = quantity;
		this.category = category;
		this.price = price;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public int getQuantity() {
		return quantity;
	}



	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}



	public String getCategory() {
		return category;
	}



	public void setCategory(String category) {
		this.category = category;
	}



	public float getPrice() {
		return price;
	}



	public void setPrice(float price) {
		this.price = price;
	}



	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", quantity="
				+ quantity + ", category=" + category + ", price=" + price
				+ "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (id != other.id)
			return false;
		return true;
	}
	
	
}
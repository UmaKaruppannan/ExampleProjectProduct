package com.cg.dao;

import java.util.List;




import javax.persistence.EntityManager;



import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Product;
import com.cg.exception.ProductException;



@Repository("productDao")
public class ProductDaoImpl implements IProductDao 
{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public ProductDaoImpl()
	{
		
	}
	
	@Override
	public int addProduct(Product product) throws ProductException
	{	
		int productID = 0;
		try
		{
			
				entityManager.persist(product);
				productID =   product.getId();
			
			
		}
		catch(Exception e)
		{
		
			throw new ProductException(e.getMessage());
		}
		
		return productID;
	}

	@Override
	public void updateProduct(Product product) throws ProductException 
	{
		try
		{
			
				entityManager.merge(product); //merge = update query
				entityManager.flush();
			
			
		}
		catch(Exception e)
		{
			
			throw new ProductException(e.getMessage());
		}

	}

	@Override
	public Product getProduct(int id) throws ProductException
	{
		Product product = null;
		try
		{
			
				product = entityManager.find(Product.class, id);
				//find = select query
			
		}
		catch(Exception e)
		{
		
			throw new ProductException(e.getMessage());
		}
		if(product==null)
		{
			throw new ProductException("No Product Found with this "+id);
		}
		
		return product;
	}

	/*@Override
	public void removeProduct(int id) throws ProductException
	{
		try
		{
			
				Product p1 = entityManager.find(Product.class, id);
				entityManager.remove(p1);
				//remove = delete query
			
		}
		catch(Exception e)
		{
		
			throw new ProductException(e.getMessage());
		}
		

	}*/

	@Override
	public List<Product> getAllProducts() throws ProductException 
	{
		List<Product> products = null;
		try
		{
			
				TypedQuery<Product> tQuery = entityManager.createNamedQuery("getAllProduct", Product.class);
				products = tQuery.getResultList();
			
			
		}
		catch(Exception e)
		{
			
			throw new ProductException(e.getMessage());
		}
		if(products== null||products.isEmpty())
		{
			throw new ProductException("No Products To Display ");
		}
		
		
		return products;
	}
/*
	@Override
	public Product getProductByName(String name) throws ProductException {
		Product p1 = null;
		try
		{
			
				TypedQuery<Product> tquery=entityManager.createQuery("select p from Product p where p.name=:Pname",Product.class);
				tquery.setParameter("Pname", name);
				p1 = tquery.getSingleResult();
			
		}
		catch(Exception e)
		{
			
			throw new ProductException(e.getMessage());
		}
		if(p1== null)
		{
			throw new ProductException("No Products in that name ");
		}
		return p1;
	}*/

	/*@Override
	public List<Product> getProductByRange(float low, float high)
			throws ProductException {
		//List<Product> products = null;
		List<Product> ListP =null;
		try
		{
			
				String qry ="Select p from Product p where p.price between :low and :high";
				TypedQuery<Product> qery = entityManager.createQuery(qry, Product.class);
				qery.setParameter("low", low);
				qery.setParameter("high", high);
				ListP= qery.getResultList();
			
		}
		catch(Exception e)
		{
			
			throw new ProductException(e.getMessage());
		}
		if(ListP== null||ListP.isEmpty())
		{
			throw new ProductException("No Products To Display ");
		}
		
		
		return ListP;
	}


*/
}
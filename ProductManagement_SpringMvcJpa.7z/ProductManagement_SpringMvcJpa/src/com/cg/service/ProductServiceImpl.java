package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IProductDao;
import com.cg.dao.ProductDaoImpl;
import com.cg.entities.Product;
import com.cg.exception.ProductException;

@Transactional
@Service("productService")
public class ProductServiceImpl implements IProductService {

	@Autowired
	IProductDao productDao ;
	public ProductServiceImpl() 
	{
		
	}
	
	public IProductDao getProductDao()
	{
		return productDao;
	}

	public void setProductDao(IProductDao productDao) 
	{
		this.productDao = productDao;
	}


	public ProductServiceImpl(IProductDao productDao) {
		super();
		this.productDao = productDao;
	}


	@Override
	public int addProduct(Product product) throws ProductException
	{
		// TODO Auto-generated method stub
		return productDao.addProduct(product);
	}

	@Override
	public void updateProduct(Product product) throws ProductException
	{
		productDao.updateProduct(product);

	}

	@Override
	public Product getProduct(int id) throws ProductException 
	{
		
		return productDao.getProduct(id);
	}

	/*@Override
	public void removeProduct(int id) throws ProductException
	{
		productDao.removeProduct(id);
	}*/
	@Override
	public List<Product> getAllProducts() throws ProductException
	{
		return productDao.getAllProducts();
	}
	/*@Override
	public Product getProductByName(String name) throws ProductException {
		
		return productDao.getProductByName(name);
	}
	@Override
	public List<Product> getProductByRange(float low, float high)
			throws ProductException {
		
		return productDao.getProductByRange(low, high);
	}*/

}

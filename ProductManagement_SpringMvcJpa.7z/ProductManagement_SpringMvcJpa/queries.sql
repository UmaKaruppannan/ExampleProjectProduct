create sequence productid_seq start with 1000 ;


select * from ProductDetails;